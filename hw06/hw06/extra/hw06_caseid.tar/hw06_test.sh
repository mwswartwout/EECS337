#
#	hw06_test.sh
#
make clean
make
./calc < math0.txt
./calc < math1.txt
./calc < math2.txt
./calc < math3.txt
./calc < math4.txt
./calc < math5.txt
./calc < math6.txt
./calc < math7.txt
./calc < math8.txt
./calc < math9.txt
