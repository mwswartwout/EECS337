#
#	hw09_test.sh
#
make clean
make
./calc +symbol < math21.txt
./calc +symbol < math22.txt
#./calc +symbol < math23.txt
