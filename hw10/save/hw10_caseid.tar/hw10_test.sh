#
#	hw10_test.sh
#
make clean
make
./calc +symbol math24.txt
./calc +symbol math25.txt
#./calc +symbol math26.txt
