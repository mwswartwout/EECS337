# hw02_test.sh
make clean
make
#./Echo2 < ../hw01/Code_1_6_1.c
#./Echo2 < ../hw01/Code_1_6_2.c
./Echo2 < Code_1_6_4.cpp
