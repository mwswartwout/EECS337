# hw04_test.sh
make clean
make
./ansi_c +symbol < ../hw01/Code_1_6_1.c
./ansi_c +symbol < ../hw01/Code_1_6_2.c
./ansi_c +symbol < ../hw02/Code_1_6_4.cpp
