/*******************************************************************************
*
* FILE:		attribute.c
*
* DESC:		EECS 337 Assignment 4
*
* AUTHOR:	caseid
*
* DATE:		September 17, 2013
*
* EDIT HISTORY:	
*
*******************************************************************************/
#include	"yystype.h"
/*
 *	attribute DEBUG functions
 */
#ifdef	YYDEBUG

/*
 *	print the attribute 
 */
void	print_attribute( int index)
{
	return;
}
/*
 *	print the attriube table
 */
void	print_attribute_table( void)
{
	return;
}
#endif

/*
 *	scanner attribute register function
 *	return an index into the attribute table (static)
 */
int	attribute( int token, char *buffer, unsigned int length, int format)
{
/*
 *	find the same string and return the index
 */
/*
 *	else update to the next attribute field
 */
/*
 *	encode the constant string into a value
 */
	return data.index;
};

