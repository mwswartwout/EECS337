#
#	hw07_test.sh
#
make clean
make
./calc < math10.txt
./calc < math11.txt
./calc < math12.txt
./calc < math13.txt
./calc < math14.txt
./calc < math15.txt
./calc < math16.txt
./calc < math17.txt
./calc < math18.txt
./calc < math19.txt
