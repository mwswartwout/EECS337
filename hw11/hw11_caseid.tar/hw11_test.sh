#
#	hw11_test.sh
#
make clean
make
./calc +symbol ../hw10/math24.txt
./calc +symbol ../hw10/math25.txt
#./calc +symbol ../hw10/math26.txt
