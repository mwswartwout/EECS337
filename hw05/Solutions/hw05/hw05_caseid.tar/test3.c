aaa
aab
baa
bab
